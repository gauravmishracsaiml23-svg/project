# 📚 Courses App - Lab Exam Project

## Tech Stack
- **Backend**: Node.js + Express + MongoDB + express-session
- **Frontend**: React + React Router v6 + Axios

---

## 📁 Folder Structure

```
courses-app/
├── backend/
│   ├── config/
│   │   └── db.js              # MongoDB connection
│   ├── middleware/
│   │   └── auth.js            # Session-based auth middleware
│   ├── models/
│   │   ├── User.js            # User schema (name, email, password)
│   │   └── Course.js          # Course schema
│   ├── routes/
│   │   ├── auth.js            # /register, /login, /logout, /auth/me
│   │   └── courses.js         # CRUD routes for /courses
│   └── server.js              # Express entry point
│
└── frontend/
    ├── public/
    │   └── index.html
    └── src/
        ├── components/
        │   └── Navbar.js      # Shows user name on top right
        ├── context/
        │   └── AuthContext.js # Session state management
        ├── pages/
        │   ├── Register.js    # /register
        │   ├── Login.js       # /login
        │   ├── CoursesList.js # /courses
        │   ├── NewCourse.js   # /courses/new
        │   ├── ShowCourse.js  # /courses/:id
        │   └── EditCourse.js  # /courses/:id/edit
        ├── App.js             # All routes defined here
        └── index.js
```

---

## 🚀 How to Run

### 1. Start MongoDB
Make sure MongoDB is running locally on port 27017.

### 2. Run Backend
```bash
cd backend
npm install
node server.js
# Runs on http://localhost:5000
```

### 3. Run Frontend
```bash
cd frontend
npm install
npm start
# Runs on http://localhost:3000
```

---

## 🔗 Routes

### Auth Routes
| Method | URL         | Description        |
|--------|-------------|-------------------|
| POST   | /register   | Register new user |
| POST   | /login      | Login             |
| POST   | /logout     | Logout            |
| GET    | /auth/me    | Get session user  |

### Course Routes
| Method | URL                    | Description            |
|--------|------------------------|------------------------|
| GET    | /courses               | All courses (READ)     |
| POST   | /courses/new           | Create course          |
| GET    | /courses/:id           | Show one course        |
| PUT    | /courses/:id/edit      | Edit course            |
| DELETE | /courses/:id/delete    | Delete course          |

---

## ✅ Lab Requirements Met

1. ✅ Schema model (User + Course)
2. ✅ CREATE, READ, EDIT, SHOW, DELETE with proper routes
3. ✅ Forms with proper inputs
4. ✅ `courseName` CANNOT be changed (disabled in form + excluded in backend)
5. ✅ Authentication with session (register/login/logout)
6. ✅ Session used to protect routes
7. ✅ Proper folder structure
8. ✅ No dummy data
9. ✅ No node_modules or package-lock.json shared
