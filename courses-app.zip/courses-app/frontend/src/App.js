import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Register from "./pages/Register";
import Login from "./pages/Login";
import CoursesList from "./pages/CoursesList";
import NewCourse from "./pages/NewCourse";
import ShowCourse from "./pages/ShowCourse";
import EditCourse from "./pages/EditCourse";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <div style={{ background: "#f5f5f5", minHeight: "calc(100vh - 56px)" }}>
          <Routes>
            {/* Auth Routes */}
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login />} />

            {/* Course Routes */}
            <Route path="/courses" element={<CoursesList />} />
            <Route path="/courses/new" element={<NewCourse />} />
            <Route path="/courses/:id" element={<ShowCourse />} />
            <Route path="/courses/:id/edit" element={<EditCourse />} />

            {/* Default */}
            <Route path="/" element={<Navigate to="/courses" />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
