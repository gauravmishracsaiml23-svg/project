import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <nav style={styles.nav}>
      <Link to="/courses" style={styles.brand}>
        📚 CoursesApp
      </Link>
      <div style={styles.links}>
        {user ? (
          <>
            <span style={styles.userName}>👤 {user.name}</span>
            <Link to="/courses/new" style={styles.link}>New Course</Link>
            <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.link}>Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

const styles = {
  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 24px",
    background: "#1a1a2e",
    color: "#fff",
  },
  brand: {
    color: "#e94560",
    textDecoration: "none",
    fontSize: "1.4rem",
    fontWeight: "bold",
  },
  links: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
  },
  link: {
    color: "#fff",
    textDecoration: "none",
    padding: "6px 14px",
    borderRadius: "4px",
    background: "#16213e",
  },
  userName: {
    color: "#e94560",
    fontWeight: "bold",
  },
  logoutBtn: {
    background: "#e94560",
    color: "#fff",
    border: "none",
    padding: "6px 14px",
    borderRadius: "4px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default Navbar;
