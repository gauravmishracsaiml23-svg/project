import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const NewCourse = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    courseName: "",
    description: "",
    instructor: "",
    duration: "",
    price: "",
  });
  const [error, setError] = useState("");

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await axios.post("/courses/new", form, { withCredentials: true });
      navigate("/courses");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to create course");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Create New Course</h2>
        {error && <p style={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <label style={styles.label}>Course Name</label>
          <input style={styles.input} name="courseName" placeholder="Course Name" value={form.courseName} onChange={handleChange} required />

          <label style={styles.label}>Description</label>
          <textarea style={styles.textarea} name="description" placeholder="Description" value={form.description} onChange={handleChange} required />

          <label style={styles.label}>Instructor</label>
          <input style={styles.input} name="instructor" placeholder="Instructor Name" value={form.instructor} onChange={handleChange} required />

          <label style={styles.label}>Duration (hours)</label>
          <input style={styles.input} name="duration" type="number" placeholder="Duration in hours" value={form.duration} onChange={handleChange} required />

          <label style={styles.label}>Price ($)</label>
          <input style={styles.input} name="price" type="number" placeholder="Price" value={form.price} onChange={handleChange} required />

          <button type="submit" style={styles.btn}>Create Course</button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: { display: "flex", justifyContent: "center", padding: "40px 20px" },
  card: { background: "#fff", padding: "40px", borderRadius: "8px", boxShadow: "0 4px 20px rgba(0,0,0,0.1)", width: "480px" },
  title: { marginBottom: "24px", color: "#1a1a2e", textAlign: "center" },
  label: { display: "block", marginBottom: "6px", fontWeight: "bold", color: "#333", fontSize: "14px" },
  input: { display: "block", width: "100%", padding: "10px", marginBottom: "16px", border: "1px solid #ddd", borderRadius: "4px", boxSizing: "border-box", fontSize: "14px" },
  textarea: { display: "block", width: "100%", padding: "10px", marginBottom: "16px", border: "1px solid #ddd", borderRadius: "4px", boxSizing: "border-box", fontSize: "14px", minHeight: "80px" },
  btn: { width: "100%", padding: "12px", background: "#e94560", color: "#fff", border: "none", borderRadius: "4px", cursor: "pointer", fontSize: "16px", fontWeight: "bold" },
  error: { color: "red", marginBottom: "12px", textAlign: "center" },
};

export default NewCourse;
