import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const CoursesList = () => {
  const [courses, setCourses] = useState([]);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/courses", { withCredentials: true }).then((res) => setCourses(res.data));
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this course?")) return;
    await axios.delete(`/courses/${id}/delete`, { withCredentials: true });
    setCourses(courses.filter((c) => c._id !== id));
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>All Courses</h2>
        {user && (
          <button onClick={() => navigate("/courses/new")} style={styles.newBtn}>
            + New Course
          </button>
        )}
      </div>
      {courses.length === 0 ? (
        <p>No courses yet. {user ? "Create one!" : "Login to create a course."}</p>
      ) : (
        <div style={styles.grid}>
          {courses.map((course) => (
            <div key={course._id} style={styles.card}>
              <h3 style={styles.courseName}>{course.courseName}</h3>
              <p style={styles.meta}>👨‍🏫 {course.instructor}</p>
              <p style={styles.meta}>⏱ {course.duration} hrs &nbsp;|&nbsp; 💰 ${course.price}</p>
              <p style={styles.desc}>{course.description}</p>
              <div style={styles.actions}>
                <Link to={`/courses/${course._id}`} style={styles.viewBtn}>View</Link>
                {user && (
                  <>
                    <Link to={`/courses/${course._id}/edit`} style={styles.editBtn}>Edit</Link>
                    <button onClick={() => handleDelete(course._id)} style={styles.deleteBtn}>Delete</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const styles = {
  container: { padding: "24px", maxWidth: "1100px", margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" },
  newBtn: { background: "#e94560", color: "#fff", border: "none", padding: "10px 20px", borderRadius: "4px", cursor: "pointer", fontWeight: "bold" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "20px" },
  card: { background: "#fff", borderRadius: "8px", padding: "20px", boxShadow: "0 2px 12px rgba(0,0,0,0.08)", borderLeft: "4px solid #e94560" },
  courseName: { color: "#1a1a2e", marginBottom: "8px" },
  meta: { color: "#666", fontSize: "13px", marginBottom: "4px" },
  desc: { color: "#444", fontSize: "14px", margin: "12px 0" },
  actions: { display: "flex", gap: "8px", marginTop: "12px" },
  viewBtn: { padding: "6px 14px", background: "#16213e", color: "#fff", textDecoration: "none", borderRadius: "4px", fontSize: "13px" },
  editBtn: { padding: "6px 14px", background: "#0f3460", color: "#fff", textDecoration: "none", borderRadius: "4px", fontSize: "13px" },
  deleteBtn: { padding: "6px 14px", background: "#e94560", color: "#fff", border: "none", borderRadius: "4px", cursor: "pointer", fontSize: "13px" },
};

export default CoursesList;
