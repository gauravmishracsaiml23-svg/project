import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const EditCourse = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    courseName: "",
    description: "",
    instructor: "",
    duration: "",
    price: "",
  });
  const [error, setError] = useState("");

  useEffect(() => {
    axios.get(`/courses/${id}`, { withCredentials: true }).then((res) => {
      const { courseName, description, instructor, duration, price } = res.data;
      setForm({ courseName, description, instructor, duration, price });
    });
  }, [id]);

  const handleChange = (e) => {
    // Prevent courseName from being changed (requirement #4)
    if (e.target.name === "courseName") return;
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await axios.put(`/courses/${id}/edit`, form, { withCredentials: true });
      navigate(`/courses/${id}`);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to update course");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Edit Course</h2>
        {error && <p style={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <label style={styles.label}>Course Name (cannot be changed)</label>
          <input
            style={{ ...styles.input, background: "#f0f0f0", cursor: "not-allowed", color: "#999" }}
            name="courseName"
            value={form.courseName}
            readOnly
            disabled
          />

          <label style={styles.label}>Description</label>
          <textarea style={styles.textarea} name="description" value={form.description} onChange={handleChange} required />

          <label style={styles.label}>Instructor</label>
          <input style={styles.input} name="instructor" value={form.instructor} onChange={handleChange} required />

          <label style={styles.label}>Duration (hours)</label>
          <input style={styles.input} name="duration" type="number" value={form.duration} onChange={handleChange} required />

          <label style={styles.label}>Price ($)</label>
          <input style={styles.input} name="price" type="number" value={form.price} onChange={handleChange} required />

          <button type="submit" style={styles.btn}>Update Course</button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: { display: "flex", justifyContent: "center", padding: "40px 20px" },
  card: { background: "#fff", padding: "40px", borderRadius: "8px", boxShadow: "0 4px 20px rgba(0,0,0,0.1)", width: "480px" },
  title: { marginBottom: "24px", color: "#1a1a2e", textAlign: "center" },
  label: { display: "block", marginBottom: "6px", fontWeight: "bold", color: "#333", fontSize: "14px" },
  input: { display: "block", width: "100%", padding: "10px", marginBottom: "16px", border: "1px solid #ddd", borderRadius: "4px", boxSizing: "border-box", fontSize: "14px" },
  textarea: { display: "block", width: "100%", padding: "10px", marginBottom: "16px", border: "1px solid #ddd", borderRadius: "4px", boxSizing: "border-box", fontSize: "14px", minHeight: "80px" },
  btn: { width: "100%", padding: "12px", background: "#0f3460", color: "#fff", border: "none", borderRadius: "4px", cursor: "pointer", fontSize: "16px", fontWeight: "bold" },
  error: { color: "red", marginBottom: "12px", textAlign: "center" },
};

export default EditCourse;
