import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const ShowCourse = () => {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`/courses/${id}`, { withCredentials: true }).then((res) => setCourse(res.data));
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm("Delete this course?")) return;
    await axios.delete(`/courses/${id}/delete`, { withCredentials: true });
    navigate("/courses");
  };

  if (!course) return <p style={{ padding: "40px" }}>Loading...</p>;

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.courseName}>{course.courseName}</h2>
        <p style={styles.meta}>👨‍🏫 Instructor: <strong>{course.instructor}</strong></p>
        <p style={styles.meta}>⏱ Duration: <strong>{course.duration} hours</strong></p>
        <p style={styles.meta}>💰 Price: <strong>${course.price}</strong></p>
        <p style={styles.meta}>👤 Created by: <strong>{course.createdBy?.name}</strong></p>
        <hr style={{ margin: "16px 0" }} />
        <p style={styles.desc}>{course.description}</p>
        {user && (
          <div style={styles.actions}>
            <Link to={`/courses/${id}/edit`} style={styles.editBtn}>Edit</Link>
            <button onClick={handleDelete} style={styles.deleteBtn}>Delete</button>
          </div>
        )}
        <Link to="/courses" style={styles.backLink}>← Back to Courses</Link>
      </div>
    </div>
  );
};

const styles = {
  container: { display: "flex", justifyContent: "center", padding: "40px 20px" },
  card: { background: "#fff", padding: "40px", borderRadius: "8px", boxShadow: "0 4px 20px rgba(0,0,0,0.1)", width: "560px" },
  courseName: { color: "#1a1a2e", marginBottom: "16px", borderLeft: "4px solid #e94560", paddingLeft: "12px" },
  meta: { color: "#555", marginBottom: "8px" },
  desc: { color: "#444", lineHeight: "1.6" },
  actions: { display: "flex", gap: "12px", marginTop: "24px" },
  editBtn: { padding: "10px 24px", background: "#0f3460", color: "#fff", textDecoration: "none", borderRadius: "4px" },
  deleteBtn: { padding: "10px 24px", background: "#e94560", color: "#fff", border: "none", borderRadius: "4px", cursor: "pointer" },
  backLink: { display: "inline-block", marginTop: "20px", color: "#666", textDecoration: "none" },
};

export default ShowCourse;
