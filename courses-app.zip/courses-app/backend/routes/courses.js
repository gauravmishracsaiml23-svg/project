const express = require("express");
const router = express.Router();
const Course = require("../models/Course");
const { isAuthenticated } = require("../middleware/auth");

// GET /courses - READ all courses
router.get("/", async (req, res) => {
  try {
    const courses = await Course.find().populate("createdBy", "name email");
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// POST /courses/new - CREATE a course
router.post("/new", isAuthenticated, async (req, res) => {
  try {
    const { courseName, description, instructor, duration, price } = req.body;

    const course = new Course({
      courseName,
      description,
      instructor,
      duration,
      price,
      createdBy: req.session.userId,
    });

    await course.save();
    res.status(201).json({ message: "Course created successfully", course });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// GET /courses/:id - SHOW a single course
router.get("/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate("createdBy", "name email");
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// PUT /courses/:id/edit - EDIT a course (courseName cannot be changed - requirement #4)
router.put("/:id/edit", isAuthenticated, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }

    // Destructure but exclude courseName from updates
    const { description, instructor, duration, price } = req.body;

    // Only update allowed fields (courseName is excluded)
    course.description = description ?? course.description;
    course.instructor = instructor ?? course.instructor;
    course.duration = duration ?? course.duration;
    course.price = price ?? course.price;

    await course.save();
    res.json({ message: "Course updated successfully", course });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// DELETE /courses/:id/delete - DELETE a course
router.delete("/:id/delete", isAuthenticated, async (req, res) => {
  try {
    const course = await Course.findByIdAndDelete(req.params.id);
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    res.json({ message: "Course deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
