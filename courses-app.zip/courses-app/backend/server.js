const express = require("express");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const cors = require("cors");
const connectDB = require("./config/db");

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS - allow frontend React app
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true, // allow cookies/session
  })
);

// Session configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || "your_secret_key_here",
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: process.env.MONGO_URI || "mongodb://localhost:27017/coursesdb",
    }),
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 1 day
      httpOnly: true,
    },
  })
);

// Routes
app.use("/register", require("./routes/auth"));  // handles /register
app.use("/login", require("./routes/auth"));      // handles /login
app.use("/logout", require("./routes/auth"));     // handles /logout
app.use("/courses", require("./routes/courses")); // handles /courses/*

// Auth session check (for React to check who's logged in)
const authRouter = require("./routes/auth");
app.use("/auth", authRouter);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
